/* Archived: See feature/storybook-csf3-migration-v4, August 2025 */
// This file is archived due to legacy button API usage. See new modular rewrite for current implementation.

// --- Original file below ---
/* eslint-disable */
import "./labs-button.js";
// import { createButtonElement, setupThemeToggle, updateThemeToggleButton } from "../tokens/button-configs.js";

/**
 * <labs-theme-toggle-button>
 * A reusable theme toggle that wraps the shared setupThemeToggle logic.
 *
 * Attributes:
 * - variant: "transparent" (default), "container", or "icon"
 *
 * Behavior:
 * - Initializes to current theme
 * - Toggles theme on click
 * - Updates icon/label to reflect current theme
 * - Keeps icon color consistent with variant
 */
class LabsThemeToggleButton extends HTMLElement {
  static get observedAttributes() {
    return ["variant"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.button = null;
    this.variant = this.getAttribute("variant") || "transparent";
  }

  connectedCallback() {
    this.render();
    this.setupThemeObserver();
  }

  disconnectedCallback() {
    if (this.themeObserver) this.themeObserver.disconnect();
  }

  attributeChangedCallback(name, oldVal, newVal) {
    if (name === "variant" && oldVal !== newVal) {
      this.variant = newVal || "transparent";
      this.render();
    }
  }

  setupThemeObserver() {
    // Keep button state synced if theme changes outside of this button
    this.themeObserver = new MutationObserver(() => {
      const isDark = document.body.classList.contains('theme-dark') || document.body.classList.contains('dark-mode');
      if (this.button) {
        this.updateThemeToggleButton(this.button, isDark);
        if (this.variant !== 'container') {
          this.button.setAttribute('iconcolor', 'var(--color-on-surface)');
        }
      }
    });
    this.themeObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  updateThemeToggleButton(button, isDarkMode) {
    button.setAttribute('icon', isDarkMode ? 'bedtime_off' : 'bedtime');
    button.setAttribute('label', isDarkMode ? 'Turn off dark mode' : 'Turn on dark mode');
  }

  render() {
    const variant = this.getAttribute("variant") || "transparent";

    // Clear and set up base styles
    this.shadowRoot.innerHTML = `
      <style>
        :host { display: ${variant === 'container' ? 'block' : 'inline-block'}; width: ${variant === 'container' ? '100%' : 'auto'}; }
        .wrap { width: ${variant === 'container' ? '100%' : 'auto'}; }
      </style>
      <div class="wrap"></div>
    `;

    const wrap = this.shadowRoot.querySelector('.wrap');

    // Create the underlying labs-button according to variant
    let btn = document.createElement("labs-button");
    if (variant === "container") {
      btn.setAttribute("variant", "container");
      btn.setAttribute("label", "Turn on dark mode");
      btn.setAttribute("icon", "bedtime");
    } else if (variant === "icon") {
      btn.setAttribute("variant", "icon");
      btn.setAttribute("icon", "bedtime");
      btn.setAttribute("aria-label", "Toggle theme");
      btn.setAttribute("iconcolor", "var(--color-on-surface)");
    } else {
      // default transparent
      btn.setAttribute("variant", "transparent");
      btn.setAttribute("label", "Turn on dark mode");
      btn.setAttribute("icon", "bedtime");
    }

    // Place the button
    wrap.appendChild(btn);
    this.button = btn;

    // Wire functionality + set initial state
    const getCurrentTheme = () => {
      if (document.body.classList.contains('theme-dark') || document.body.classList.contains('dark-mode')) {
        return 'dark';
      }
      if (document.body.classList.contains('theme-light')) {
        return 'light';
      }
      try {
        const storedTheme = localStorage.getItem('theme') || localStorage.getItem('preferred-theme');
        if (storedTheme) return storedTheme;
      } catch (e) { }
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
      return 'light';
    };

    const applyTheme = (theme) => {
      const isDark = theme === 'dark';
      if (isDark) {
        document.body.classList.add('theme-dark', 'dark-mode');
        document.body.classList.remove('theme-light');
      } else {
        document.body.classList.add('theme-light');
        document.body.classList.remove('theme-dark', 'dark-mode');
      }
      try {
        localStorage.setItem('theme', theme);
        localStorage.setItem('preferred-theme', theme);
      } catch (e) { }
      this.updateThemeToggleButton(btn, isDark);
      if (variant !== 'container') {
        btn.setAttribute('iconcolor', 'var(--color-on-surface)');
      }
    };

    // Set initial state
    const currentTheme = getCurrentTheme();
    applyTheme(currentTheme);

    // Toggle theme on click
    btn.addEventListener('click', () => {
      const currentTheme = getCurrentTheme();
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(newTheme);
    });
  }
}

customElements.define("labs-theme-toggle-button", LabsThemeToggleButton);
