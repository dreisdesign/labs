This folder is for archived components. Move all legacy stories and components here to remove them from Storybook.
