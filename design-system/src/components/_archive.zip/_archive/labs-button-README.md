# Labs Button Component

> Modular, robust, and portable button for the Labs Design System.

---

## Archived Components & Stories (August 2025)
- All components and stories referencing old button APIs (except the new modular button) have been archived to `_archive/`.
- **labs-theme-toggle-button.js** and **labs-undo-button.js** are archived and will be rebuilt from scratch using the new modular button API.
- All old button-based components/stories will be rebuilt as fully modular, explicit components.

---

## 1. Overview

The `labs-button` is a fully modular web component:
- All styles and logic are self-contained (Shadow DOM, no global CSS)
- Explicit API: configure via attributes and CSS custom properties
- Slot-based content for label, icons, and extra content
- Zero dependencies: no external CSS, fonts, or scripts
- All visual aspects are CSS custom properties with sensible defaults
- Multiple instances are fully isolated

---

## 2. Variants

Supported variants (see code for full list):
- `primary` (default)
- `secondary`
- `destructive`
- `icon` (icon-only, minimal style)
- `container` (neutral background)

**Example:**
```html
<labs-button variant="primary" size="lg">
  <span slot="icon-left"><labs-icon name="add"></labs-icon></span>
  <span>Save</span>
</labs-button>

<labs-button variant="icon" icon="settings"></labs-button>
```

---

## 3. CSS Custom Properties (Tokens)

| Property                        | Default         | Description                       |
|---------------------------------|-----------------|-----------------------------------|
| --button-bg                     | #fff            | Button background                 |
| --button-color                  | #333            | Button text/icon color            |
| --button-radius                 | 8px             | Border radius                     |
| --button-padding                | 1rem            | Padding                           |
| --button-font                   | system-ui       | Font family                       |
| --button-icon-size              | 1em             | Icon size                         |
| --button-icon-only-hover-bg     | #f0f0f0         | Icon-only hover background        |
| ...                             |                 | See code for full list            |

---


## 4. API & Controls

### Attributes / Controls

| Attribute      | Type     | Default    | Description                                              |
|---------------|----------|------------|----------------------------------------------------------|
| variant       | string   | primary    | Visual style: primary, secondary, destructive, icon, etc.|
| size          | string   | md         | Size: sm, md, lg                                         |
| icon          | string   |            | Name of icon (shows icon-only if no label/slot)          |
| icon-left     | string   |            | (Optional) Name of left icon (slot preferred)            |
| icon-right    | string   |            | (Optional) Name of right icon (slot preferred)           |
| disabled      | boolean  | false      | Disables the button                                      |
| aria-label    | string   |            | Accessibility label (required for icon-only)             |

### Slots

- `icon-left`: for left icon (preferred: use `<span slot="icon-left"><labs-icon ...></labs-icon></span>`)
- default: for label/content
- `icon-right`: for right icon

### Accessibility
- All focus/hover/active states are present
- Use `aria-label` for icon-only buttons

---

## 5. Where to Find Docs

- **Component README:** (this file)
- **Storybook:** _Live examples, code, and controls_
  - [Labs Design System Storybook](../../../../storybook-static/index.html?path=/docs/components-labs-button--docs)
- **Tokens:** See [tokens documentation](../../tokens/README.md) for global design tokens
- **Global Dev Guide:** [DEVELOPMENT.md](../../../docs/DEVELOPMENT.md)

---

## 6. Live Examples

See Storybook for interactive examples and source code for all variants and patterns.

---

## 7. Modularity Statement

This component is fully modular: requires no external CSS, is configurable via attributes and CSS custom properties, and can be dropped into any project with zero dependencies.

---

## 8. Benefits

- **Portability:** Works anywhere, in any project
- **Customizability:** Theming via CSS only
- **Reliability:** No global conflicts
- **Maintainability:** Easy to update and extend

---

## 9. Theme Testing & Storybook Integration

### Modular Theme Testing (Smoothie System)

- The `labs-button` supports modular theme switching via CSS custom properties and Storybook toolbar controls (see the Smoothie metaphor in `../../../../smoothie.md`).
- Use the Storybook toolbar to switch both "Flavor" (theme) and "Theme" (light/dark) for live preview/testing.
- All tokens are mapped to real CSS custom properties (see [smoothie.md](../../../../smoothie.md) for token sets and mapping tables).

### Sample Storybook Test Story

Add this to your `labs-button.stories.js` (or `.stories.mjs`/`.stories.ts`):

```js
import './labs-button.js';

export default {
  title: 'Components/Labs Button',
  argTypes: {
    variant: { control: 'select', options: ['primary', 'secondary', 'destructive', 'icon', 'container'] },
    size: { control: 'select', options: ['sm', 'md', 'lg'] },
    disabled: { control: 'boolean' },
    icon: { control: 'text' },
    'aria-label': { control: 'text' },
  },
  parameters: {
    docs: {
      description: {
        component: 'Modular, theme-agnostic button. Use the Storybook toolbar to switch Flavor (theme) and Theme (light/dark).',
      },
    },
  },
};

const Template = (args) => {
  return `
    <labs-button
      variant="${args.variant}"
      size="${args.size}"
      icon="${args.icon || ''}"
      aria-label="${args['aria-label'] || ''}"
      ${args.disabled ? 'disabled' : ''}
    >
      ${args.variant !== 'icon' ? 'Button' : ''}
    </labs-button>
  `;
};

export const Basic = Template.bind({});
Basic.args = {
  variant: 'primary',
  size: 'md',
  disabled: false,
  icon: '',
  'aria-label': '',
};
```

**Where to place:**
- Place this story in `src/components/labs-button/labs-button.stories.js` (or `.ts`/`.mjs` as appropriate).
- Storybook will auto-detect and display it under "Components > Labs Button".

**How to test:**
- Use the Storybook toolbar to switch Flavor (theme) and Theme (light/dark) and verify the button updates live.
- All tokens and variants are mapped as described in the Smoothie system.

---

-- Continue refining button and pattern variants
-- Add/expand Storybook Docs (usage, API, CSS custom properties)
-- See [DEVELOPMENT.md](../../../docs/DEVELOPMENT.md) for roadmap
