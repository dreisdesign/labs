# Modular Button System: Refactor Plan & Principles

**Goal:**
Create a truly modular, robust, and portable button component for the Labs Design System, following the strictest modularity and configuration guidelines.

---

## 0. Archive & Rebuild Plan (August 2025)
- All components and stories referencing old button APIs (except the new modular button) have been archived to `_archive/`.
- **labs-theme-toggle-button.js** and **labs-undo-button.js** are archived and will be rebuilt from scratch using the new modular button API.
- All old button-based components/stories will be rebuilt as fully modular, explicit components.
- See README for current status and roadmap.

---

## 1. Core Principles
- **Self-contained:** All styles and logic live inside the component (Shadow DOM, no global CSS).
- **Explicit API:** All configuration via attributes and CSS custom properties—no hidden logic.
- **Slot-based content:** Use slots for label, icons, and any extra content.
- **Zero dependencies:** No reliance on external CSS, fonts, or scripts.
- **Configurable:** All visual aspects (color, radius, padding, etc.) are CSS custom properties with sensible defaults.
- **Isolated:** Multiple instances on a page never conflict.

---

## 2. Refactor Steps
1. **Remove all implicit/variant logic**
   - Only explicit attributes (e.g., `variant`, `icon`, `icon-left`, `icon-right`, `size`, etc.)
2. **Move all styles into Shadow DOM**
   - No global selectors, no external CSS
3. **Expose all content via slots**
   - `<slot name="icon-left">`, `<slot>`, `<slot name="icon-right">`, etc.
4. **Replace all hardcoded values with CSS custom properties**
   - E.g., `background: var(--button-bg, #fff);`
5. **Document all custom properties and attributes**
   - Usage, defaults, and examples
6. **Test drop-in, zero-dependency, and isolation**
   - Copy to a blank HTML file and verify full function

---


## 3. Example Modular Button API
```html
<labs-button variant="primary" size="lg" icon="add">
   <span slot="icon-left"><labs-icon name="add"></labs-icon></span>
   <span>Save</span>
</labs-button>

<!-- Icon-only: special minimal style (no bg, no border, only icon and icon hover) -->
<labs-button variant="icon" icon="settings"></labs-button>
```

---

## 3a. Icon-Only Variant: Special Treatment
- The `icon` variant is a unique visual style:
   - **No background, no border**
   - Only the icon is visible
   - On hover: subtle background or icon color change (configurable)
   - No label, no padding except for icon touch target
- Use `variant="icon"` for this minimal style.
- All accessibility and focus states must still be present.

---
